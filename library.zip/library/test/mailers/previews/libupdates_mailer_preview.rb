# Preview all emails at http://localhost:3000/rails/mailers/libupdates_mailer
class LibupdatesMailerPreview < ActionMailer::Preview

end
