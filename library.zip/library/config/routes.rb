Rails.application.routes.draw do
  resources :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  #resources :books

  root 'pages#home'
  resources :books #, only: [:show, :index, :new, :create, :edit , :update, :destroy]
  get '/signup' => "users#new"
  get '/login'  => "sessions#new"
  post '/login'  => "sessions#create"
  delete '/logout' => "sessions#destroy"
  get '/returnbook/:id', to: "books#retbook", as: "returnbook"
  get '/updatereq/:id', to:"books#updatereq", as: "updatereq"
  get '/returnbook/:id', to: "books#returnreq", as:"retreq"
  get '/editrequest/:id', to: "books#editreq", as: "editreq"
  get '/showrequest/:id', to: "books#showreq", as: "showreq"
  get '/request/:id' , to: "books#requestBook", as: "req"
  get '/allrequests/', to: "books#allrequests", as: "allreqs"
  get '/changerequest/:id', to: "books#changereq", as: "changereq"
  match '/request/',to: "books#requestBook", via: :get 
end
