class BooksController < ApplicationController

     def show
          @book = Book.find(params[:id])
          puts session[:user_id]
          requests = @book.requests 
          requests.each do |req|
               puts "book_id:",req.book_id
          end
          puts params
     
     end 

     def index
          @books = Book.all
     end

     def new
         @book = Book.new
     
     end

     def create
          #render plain: params[:book]
          @book = Book.new(params.require(:book).permit(:isbn, :title, :authors,:publication, :category, :count))

          if @book.save
               redirect_to @book
          else
               render :new, status: :unprocessable_entity
          end
     end

     def edit 
          @book = Book.find(params[:id])

     end 

     def update
          @book = Book.find(params[:id])
          if @book.update(params.require(:book).permit(:isbn, :title, :authors,:publication, :category,:count))
               redirect_to action: :index
          else
               render :edit,status: :unprocessable_entity
          end
     end

     def destroy
          @book = Book.find(params[:id])
          puts @book
          @book.destroy
          redirect_to action: :index
     end

     def retbook
          req_id = params[:id]
          @req = Request.find_by(id:req_id)
          if @req.update(params.require(:request).permit(:book_id, :user_id, :status))
               redirect_to action: :allrequests
          else
               render editreq_path,status: :unprocessable_entity
          end
     end

     def requestBook
          #puts params
          user = User.find_by(id: session[:user_id])
          book = Book.find(params[:id])
          #puts @book.id , @book.title
          rq = Request.new
          rq.user_id = session[:user_id]
          rq.book_id = params[:id]
          rq.status = 0;
          if rq.save
               puts "request_saved"
          else
               puts "failed saving request"
          end
          redirect_to  user_path(user)
          #render plain: "Yayy!! "

     end

     def updatereq
          req_id = params[:id]
          @req = Request.find_by(id:req_id)
          if @req.update(params.require(:request).permit(:book_id, :user_id, :status))
               redirect_to action: :allrequests
          else
               render editreq_path,status: :unprocessable_entity
          end
     end

     def editreq
          req_id = params[:id]
          puts "Here",params
          @req = Request.find_by(id:req_id)

     end

     def changereq
          req_id = params[:id]
          @req = Request.find_by(id:req_id)
          @guest = User.find_by(id:@req.user_id)
          @b = Book.find_by(id:@req.book_id)
          redirect_to showreq_path(req_id)
     end

     def allrequests
          @reqs = Request.where('status = ?',0)
          @reqs1 = Request.where('status = ?',1)
     end
     
     def showreq
          req_id = params[:id]
          @req = Request.find_by(id:req_id)
          @guest = User.find_by(id:@req.user_id)
          @b = Book.find_by(id:@req.book_id)
     end
end