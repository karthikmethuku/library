class SessionsController < ApplicationController

    def new 
    
    end

    def create
        #puts params[:session][:username]
        #puts params[:session][:password]  
        
        user = User.find_by(username: params[:session][:username])
        if user && user.authenticate(params[:session][:password])
            session[:user_id] = user.id;
            redirect_to user
        else
            flash.now[:notice] = "Wrong Credentials"
            render 'new'#,status: :unprocessable_entity
            
            #redirect_to root_path
        end


    end

    def destroy
        session.destroy
        #flash[:notice] = "Logged Out"
        redirect_to  root_path, status: :see_other
    
    end

end
