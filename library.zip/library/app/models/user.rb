class User < ApplicationRecord 
    validates :username, presence: true,
                            uniqueness: {case_sensitive: false}
    validates :email, presence: true,
                            uniqueness: {case_sensitive: false}

    has_many :requests
    has_many :books, through: :requests

    has_secure_password
end
