class Book < ApplicationRecord 
    validates :isbn, presence: true, length: { minimum: 1, maximum:17 }
    validates :title, presence: true, length: { minimum: 1, maximum:50 }

    has_many :requests 
    has_many :users, through: :requests
     
end