module UsersHelper

    def isAdmin(user)
        if user.nil?
           return false
        end
        if !user.level.nil?
            if user.level > 5
                true
            else
                false
            end
        else
            false
        end

    end

end
