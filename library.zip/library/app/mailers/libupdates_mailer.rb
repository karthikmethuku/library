class LibupdatesMailer < ApplicationMailer
end
